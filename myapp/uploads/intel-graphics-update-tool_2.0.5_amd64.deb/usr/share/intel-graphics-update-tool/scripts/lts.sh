#!/bin/bash

# verify that we _can_ upgrade to -lts-<target>
# verify that we haven't upgraded _past_ -lts-<target>
# return the list of packages

target="$1"; shift;
packages="$@";
this_pattern='-lts-'"${target}$";
next_letter=${target:0:1};
next_letter=$(echo $next_letter | tr a-z b-za);
next_pattern='-lts-'"${next_letter}[a-z]+$";
search='grep-aptavail -FPackage -e'
later=;
missing=;
found=;

for pkg in $packages;
do
    pkg=${pkg%%-lts-*};

    # find the required package in the -lts-xxx version we want
    tver=$($search "^$pkg$this_pattern" -ns Package | uniq);
    # check to see if there's a later -lts-xxx version available
    nver=$($search "^$pkg$next_pattern" -ns Package | uniq);

    if [ -n "$tver" ];
    then
        if [ -n "$nver" ];
        then
            # our target lts version has been superseded
            later=${nver##*-lts-};
            break;
        else
            found=${found}${found:+ }${tver};
        fi;
    else
        missing=${missing}${missing:+ }${pkg}-lts-$target;
    fi;
done;

# More recent LTS pack availabe: User should install that instead;
if [ -n "$later" ];
then
    echo "$later";
    exit 2;
fi

# Some lts packages we want are missing. Shouldn't be possible
# unless a repo is unreachable and hasn'e been updated for a while?
# in any case, bail out and complain:
if [ -n "$missing" ];
then
    for x in $missing; do echo $x; done;
    # if we found at least one lts-xxx package we expected, we're good
    # to go: it's possible for the distro to have an incomplete lts update
    # in which case the rest of the packages will come from our repos,
    # but our repos may not be configured yet.
    # If we found _no_ packages, then the LTS update we want is unavailable
    # and we cannot proceed:
    if [ -z "$found" ]; then exit 1; fi;
fi

# clean bill of health. proceed.
exit 0;
